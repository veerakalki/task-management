package com.example.uploadfilesdatabase;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadFilesDatabaseApplicationTests {

	

}
